﻿using System; 
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using UploadImage.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace UploadImage.Controllers
{
    public class UploadImageController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<string> UploadFile(Image image)
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: true)
                .Build();

            if (image.ImageUrl == null || image.ImageUrl.Length == 0)
                return "file not selected";
            if (image.FileDirectory == null || image.FileDirectory.Length == 0)
                return "file directory not found";
            var directory = Directory.CreateDirectory(config.GetValue<string>("files:locations").ToString()+image.FileDirectory);
            var path = Path.Combine(
                        Directory.GetCurrentDirectory(),directory.ToString(),
                        image.ImageUrl.FileName.ToString());

            using (var stream = new FileStream(path, FileMode.Create))
            {
                await image.ImageUrl.CopyToAsync(stream);
            }

            return "Upload complete, Your image have saved into :"+ directory;
        }
    }
}