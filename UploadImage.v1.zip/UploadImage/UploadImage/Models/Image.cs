﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UploadImage.Models
{
    public class Image
    {
        public int ImageID { get; set; }
        public IFormFile ImageUrl { get; set; }
        public string FileDirectory { get; set; }
    }
}
